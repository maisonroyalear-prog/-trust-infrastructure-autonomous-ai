# ADR-RI-002 — Monorepo Strategy

Status: Accepted

Decision: V1 uses one repository with npm workspaces under `apps/*` and `packages/*`.
