# M0-STEP-01 Preflight Review

This review was performed before the network-dependent lockfile verification.

Static corrections applied:

- Corrected the TypeScript baseline from 7.0.2 to 5.9.3 because the selected `typescript-eslint` version officially supports TypeScript `<6.1.0`; Node.js 24.19.0 and npm 11.17.0 remain unchanged. ADR-RI-009 records this compatibility correction.

- Added explicit `@eslint/js` dependency because `eslint.config.mjs` imports it directly.
- Added a minimal `tsconfig.json` to every workspace and project references in the root `tsconfig.json`, so workspace `tsc -b` commands have a real project to build.
- Replaced `.gitkeep` source placeholders with `export {};` module stubs only; no domain/application semantics were added.
- Changed the bootstrap test command to `vitest run --passWithNoTests` so M0 can verify the test runner before M1 introduces real tests.
- Strengthened `repo:check` to verify runtime/npm/TypeScript pins, workspace TypeScript project references, explicit ESLint dependency, read-only normal CI shape, and empty implementation boundaries.

The step remains **BLOCKED** until npm 11.17.0 under Node.js 24.19.0 can reach the npm registry, generate a real `package-lock.json`, and successfully run the clean-install verification commands.
