# M0-STEP-01 — Toolchain Decision & Repository Bootstrap

## Scope boundary

This step locks only the engineering substrate. No canonical domain objects, state machines, Trust Decision Engine, Gateway execution, Evidence, or Receipt logic is implemented here.

## Locked decisions

| Layer | Locked choice | Reason / trade-off |
|---|---|---|
| Primary backend | TypeScript 5.9.3 + Node.js 24.19.0 LTS | Strict static typing, runtime-schema alignment, strong HTTP/PostgreSQL ecosystem, SDK/type reuse, and a supported `typescript-eslint` compatibility range. TypeScript 7 is postponed by ADR-RI-009 until the lint stack officially supports it. Main JS numeric-semantics risk remains deferred as a hard M1/M2 Money/NUMERIC constraint. |
| Package manager | npm 11.17.0 | Ships with selected Node LTS, supports workspaces and one lockfile, minimizes bootstrap dependencies. pnpm is faster but adds another tool to provision. |
| Repository | One monorepo with `apps/*` and `packages/*` | Atomic changes across contracts/apps/packages; avoids premature multi-repository coordination. |
| HTTP framework | Fastify 5.12.1 | Low magic, lifecycle hooks, middleware/plugin model, test injection, mature TypeScript support. NestJS rejected for M0 due extra framework complexity. |
| PostgreSQL access | Kysely 0.29.5 + `pg` 8.23.0 | SQL-first and type-safe while keeping transactions, raw SQL, locking, CAS, JSONB and PostgreSQL semantics visible. Full ORM abstraction rejected because concurrency must remain explicit. |
| Migrations | node-pg-migrate 9.0.0 | Ordered PostgreSQL-aware migrations with raw SQL support and CI suitability. No schema mutation on application startup. |
| Runtime validation | Zod 4.4.3 | Runtime validation plus inferred TS types; avoids manually duplicating schemas. Receipt canonicalization will remain a separate concern. |
| Unit/integration tests | Vitest 4.1.11 | TypeScript-first, async-friendly, fast local loop. |
| Property tests | fast-check 4.9.0 | Lightweight property testing with shrinking for M1+ invariants. |
| Lint/format | ESLint 10 + typescript-eslint + Prettier 3 | Strict correctness-focused linting and one formatter. |

## Explicit non-decisions / exclusions

No Kafka, Redis, graph database, Elasticsearch/OpenSearch, Kubernetes, blockchain, custom IAM, custom KMS, custom cryptography, or microservices architecture is introduced in M0.

## Dependency direction to enforce from M0 onward

`apps / infrastructure -> application -> domain`

`packages/domain` must never import Fastify, PostgreSQL libraries, cloud SDKs, Mock ERP, KMS providers, or object-store providers.
