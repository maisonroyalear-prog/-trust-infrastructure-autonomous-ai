# ADR-RI-004 — Package Manager

Status: Accepted

Decision: npm 11.17.0 with one committed `package-lock.json`.
