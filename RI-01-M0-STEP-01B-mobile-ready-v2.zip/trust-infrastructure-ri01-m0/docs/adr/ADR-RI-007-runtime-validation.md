# ADR-RI-007 — Runtime Validation

Status: Accepted

Decision: Zod 4.4.3 for runtime validation and inferred TypeScript types.
