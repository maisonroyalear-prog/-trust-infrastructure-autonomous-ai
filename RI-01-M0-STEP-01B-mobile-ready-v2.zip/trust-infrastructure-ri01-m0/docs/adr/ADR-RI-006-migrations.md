# ADR-RI-006 — Migration Tool

Status: Accepted

Decision: node-pg-migrate 9.0.0. Production schema changes are deployment actions, not automatic application-startup behavior.
