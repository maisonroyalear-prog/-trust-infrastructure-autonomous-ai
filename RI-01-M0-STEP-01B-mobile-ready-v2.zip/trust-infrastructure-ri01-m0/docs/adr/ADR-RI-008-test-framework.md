# ADR-RI-008 — Test Framework

Status: Accepted

Decision: Vitest 4.1.11 for unit/integration tests and fast-check 4.9.0 for property testing.
