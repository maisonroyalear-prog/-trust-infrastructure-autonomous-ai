# ADR-RI-009 — TypeScript Compatibility Baseline

Status: Accepted

Date: 2026-09-01

## Context

The M0 preflight originally pinned TypeScript 7.0.2 together with `typescript-eslint` 8.67.0 and ESLint 10.9.0.

TypeScript 7.0.2 is a published stable TypeScript release. However, the official `typescript-eslint` dependency compatibility page currently states support for TypeScript `>=4.8.4 <6.1.0`. Using TypeScript 7 would therefore place the M0 baseline outside the linter's supported TypeScript range before the first clean CI acceptance.

Official compatibility reference:
https://typescript-eslint.io/users/dependency-versions/

## Decision

For RI-01 / M0, pin TypeScript **5.9.3** while keeping:

- Node.js **24.19.0 LTS** unchanged;
- npm **11.17.0** unchanged;
- ESLint **10.9.0** unchanged;
- `typescript-eslint` **8.67.0** unchanged.

TypeScript 7 is postponed, not rejected. It may be adopted later through a separate ADR after the selected lint/type-aware tooling officially supports it and the repository passes a clean compatibility verification.

## Reasoning

M0 should establish a supported, reproducible engineering substrate rather than maximize compiler novelty. The Trust Core architecture does not depend on TypeScript 7-specific language features. TypeScript 5.9.3 provides the required strict static typing while keeping the lint/typecheck combination inside the officially supported compatibility range.

## Consequences

- No architecture or domain redesign is required.
- No change is made to the locked Node/npm runtime.
- TypeScript 7-specific syntax/features must not be introduced before a future upgrade ADR.
- A later TypeScript 7 upgrade should be treated as a toolchain migration with clean CI evidence, not an architectural milestone.
