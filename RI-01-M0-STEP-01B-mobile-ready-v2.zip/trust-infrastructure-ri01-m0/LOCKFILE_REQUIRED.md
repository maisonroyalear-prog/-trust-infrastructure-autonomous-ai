# STEP-01 blocker: package-lock.json

The execution sandbox cannot currently reach the npm registry, so a truthful transitive lockfile cannot be generated here.

On a connected machine using Node 24.19.0 / npm 11.17.0 run:

```bash
npm install --package-lock-only --ignore-scripts
npm ci --ignore-scripts
npm run repo:check
```

Commit the generated `package-lock.json`, then delete this blocker file.
