# ADR-RI-001 — Primary Backend Runtime

Status: Superseded by ADR-RI-009

Original decision: TypeScript 7 on Node.js 24.19.0 LTS was selected as the canonical V1 Trust Core runtime. Python may later be used for SDK/evaluation/tooling, not as a competing Trust Core.

Reason for supersession: before M0 acceptance, compatibility review found that the selected `typescript-eslint` release does not officially support TypeScript 7. The Node.js/npm runtime decision remains unchanged; only the TypeScript compiler baseline is corrected in ADR-RI-009.
