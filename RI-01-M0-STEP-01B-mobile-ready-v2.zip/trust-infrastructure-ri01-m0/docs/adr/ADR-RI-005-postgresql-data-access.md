# ADR-RI-005 — PostgreSQL Data Access

Status: Accepted

Decision: Kysely 0.29.5 over `pg` 8.23.0. PostgreSQL-specific locking and transactions must remain explicit and raw SQL must remain available.
