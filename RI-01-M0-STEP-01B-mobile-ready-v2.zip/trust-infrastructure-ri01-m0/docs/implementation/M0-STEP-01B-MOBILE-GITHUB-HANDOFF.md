# M0-STEP-01B — Mobile / GitHub Handoff

This handoff exists because the current ChatGPT shell cannot reach npm/Node download hosts and the connected GitHub integration can read the repository but cannot write repository contents.

The repository must stay at **M0-STEP-01 = BLOCKED** until an Internet-connected GitHub Actions runner verifies the exact locked toolchain and generates a real npm lockfile.

## Minimal mobile path

Only two manual GitHub actions are required from a phone/tablet browser:

1. Upload the provided `RI-01-M0-STEP-01B-mobile-ready-v2.zip` file to the repository root. GitHub/browser duplicate suffixes such as `(1)` are safe because the bootstrap identifies the handoff by SHA-256, not by an exact filename.
2. Create `.github/workflows/bootstrap-from-handoff-zip.yml` using the separately provided V2 workflow, then run it once with **Run workflow**.

The bootstrap workflow will:

- locate the handoff ZIP by cryptographic checksum;
- extract the repository skeleton;
- remove the uploaded ZIP and the one-time bootstrap workflow from the final tree;
- set up Node.js 24.19.0 and verify bundled npm 11.17.0;
- generate a genuine npm `package-lock.json`;
- run `npm ci`;
- run the complete M0 STEP-01 verification suite;
- commit and push only after those checks pass;
- explicitly dispatch the normal read-only `ci.yml` workflow against the committed SHA;
- wait for that normal CI run and fail the bootstrap if normal CI fails.

The explicit dispatch is required because GitHub does not normally create a second workflow run from a `push` performed with the repository `GITHUB_TOKEN`; `workflow_dispatch` is the deliberate exception used here.

## Acceptance rule

Do not manually edit `package-lock.json` and do not mark PASS because the bootstrap merely started.

PASS requires both:

- successful one-time bootstrap verification and committed npm-generated `package-lock.json`;
- successful normal `ci.yml` verification from the committed lockfile.

The V2 bootstrap waits for the normal CI result, so a green bootstrap run is sufficient evidence that both stages succeeded, subject to reviewing the actual GitHub Actions run logs before changing the milestone status.
