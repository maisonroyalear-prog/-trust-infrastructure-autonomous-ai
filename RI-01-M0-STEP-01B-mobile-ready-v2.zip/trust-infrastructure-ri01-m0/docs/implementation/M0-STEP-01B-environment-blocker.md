# M0-STEP-01B — Environment Blocker

Status: BLOCKED pending execution in an Internet-connected runner.

## Current sandbox evidence

Verified in the current shell environment:

- Node: v22.16.0
- npm: 10.9.2
- nvm: 0.40.3 at `/opt/nvm/nvm.sh`
- installed nvm runtime: Node v22.16.0 only
- locked Node v24.19.0: not installed locally and not available from the local nvm cache
- npm package cache: no reusable package entries found
- DNS/network access to `registry.npmjs.org`: unavailable
- DNS/network access to `nodejs.org`: unavailable from the shell environment
- static repository bootstrap check: PASS
- local secret scan: PASS
- exact toolchain check: expected failure because the shell runtime is not the locked runtime

## Locked target remains unchanged

- Node: 24.19.0
- npm: 11.17.0

Official Node.js 24.19.0 release evidence confirms npm 11.17.0 is bundled with the locked runtime. This is an **environment blocker**, not an architecture failure.

There is no truthful way in this sandbox to generate the required lockfile or claim clean-install verification. We must not hand-write a lockfile, fake runtime output, or mark M0-STEP-01 PASS.

## Correct closure path

Run the prepared bootstrap in an Internet-connected GitHub-hosted runner. It must:

1. run Node.js 24.19.0 and npm 11.17.0;
2. generate `package-lock.json` using npm itself;
3. run `npm ci` from that generated lockfile;
4. run repository, formatting, lint, typecheck, test, build, secret-scan, and dependency-audit checks;
5. commit the verified lockfile only after all checks succeed;
6. then run the normal CI workflow from the committed lockfile.

M0-STEP-01 remains BLOCKED until those conditions are actually satisfied.
