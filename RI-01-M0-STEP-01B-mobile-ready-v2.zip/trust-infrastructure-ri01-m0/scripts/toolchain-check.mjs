import { execFileSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';

const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const expectedNode = `v${pkg.engines.node}`;
const expectedNpm = pkg.engines.npm;

const actualNode = process.version;
const npmCommand = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const actualNpm = execFileSync(npmCommand, ['--version'], { encoding: 'utf8' }).trim();

if (actualNode !== expectedNode) {
  throw new Error(`Node runtime mismatch: expected ${expectedNode}, got ${actualNode}`);
}

if (actualNpm !== expectedNpm) {
  throw new Error(`npm runtime mismatch: expected ${expectedNpm}, got ${actualNpm}`);
}

console.log(`Toolchain check: PASS (${actualNode} / npm ${actualNpm})`);
