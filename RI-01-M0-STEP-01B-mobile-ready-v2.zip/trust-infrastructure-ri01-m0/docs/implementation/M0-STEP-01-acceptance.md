# M0-STEP-01 Acceptance

STATUS: BLOCKED

Verified PASS:
- Required monorepo directories and workspace manifests exist.
- Node/npm/Fastify/Kysely/Zod choices are pinned in machine-readable configuration.
- Static repository bootstrap check passes.
- Every workspace has a minimal TypeScript project skeleton and is referenced by the root TypeScript build graph.
- `@eslint/js` is explicitly declared because the ESLint config imports it directly.
- Bootstrap test command is configured to validate the Vitest runner without pretending M0 already has M1 tests.
- Domain and all other source packages contain only `export {};` skeleton modules; no trust/domain implementation has been introduced.
- Exact toolchain verification is automated by `scripts/toolchain-check.mjs`.
- A strong-pattern local secret scan is automated by `scripts/secret-scan.mjs`.
- `.npmrc` enforces exact engine usage for installs, lockfile creation, and exact saved versions.
- The one-time Internet-connected lockfile bootstrap and normal CI workflows are prepared.
- TypeScript 5.9.3 is pinned inside the selected `typescript-eslint` official compatibility range; TypeScript 7 is postponed by ADR-RI-009 rather than accepted in an unsupported lint configuration.
- Publication of the pinned top-level packages has been pre-flight checked.

Blocked:
- The available shell sandbox is not the locked Node.js 24.19.0 / npm 11.17.0 runtime.
- nvm is present, but only Node v22.16.0 is installed locally; Node v24.19.0 is not available in the local nvm cache.
- External DNS/network access is unavailable from that shell sandbox, so nvm/npm cannot fetch the locked runtime or dependencies.
- A truthful `package-lock.json` therefore cannot be generated or `npm ci` verified in the current shell.

STEP-01 cannot become PASS until, under Node.js 24.19.0 / npm 11.17.0, a real lockfile is generated and these checks succeed:

```bash
npm run toolchain:check
npm install --package-lock-only --ignore-scripts
npm ci
npm run ci:local
```
