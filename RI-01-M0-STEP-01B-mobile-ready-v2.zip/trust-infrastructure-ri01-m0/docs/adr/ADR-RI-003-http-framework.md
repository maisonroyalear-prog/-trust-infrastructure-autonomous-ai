# ADR-RI-003 — HTTP Framework

Status: Accepted

Decision: Fastify 5.12.1.
