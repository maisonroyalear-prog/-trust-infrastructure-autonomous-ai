# M0-STEP-01B — Runtime and Package Availability Evidence

Status: PRE-FLIGHT VERIFIED; install verification still BLOCKED in the current sandbox.

## Locked runtime

- Node.js 24.19.0 LTS
- npm 11.17.0

Official Node.js 24.19.0 release notes state that this exact Node release upgraded the bundled npm to 11.17.0. The CI bootstrap therefore uses the Node distribution's bundled npm and verifies both versions instead of mutating the runner with a global npm install.

Official source:
https://nodejs.org/en/blog/release/v24.19.0

## Current sandbox runtime evidence

- Node: v22.16.0
- npm: 10.9.2
- nvm: 0.40.3 is present
- only Node v22.16.0 is locally installed through nvm
- Node v24.19.0 is not present in the local nvm installation/cache
- npm package cache contains no reusable package payloads
- registry and Node download hosts are not resolvable from the shell environment

Therefore the locked runtime cannot be truthfully executed here without external network access.

## Direct package publication pre-flight

The pinned top-level packages were checked for publication before attempting the real lockfile bootstrap, including Fastify 5.12.1, Kysely 0.29.5, TypeScript 5.9.3, ESLint 10.9.0, @eslint/js 10.0.1, Vitest 4.1.11, fast-check 4.9.0, node-pg-migrate 9.0.0, tsx 4.23.12, Prettier 3.9.6, typescript-eslint 8.67.0, pg 8.23.0, Pino 10.3.1, Zod 4.4.3, @fastify/cors 11.3.0, and @fastify/helmet 13.1.1.

This is only publication pre-flight evidence. It does **not** replace dependency resolution, npm-produced lockfile generation, `npm ci`, peer-dependency validation, or the full CI verification suite.

## TypeScript / lint compatibility correction

A later compatibility review found that `typescript-eslint` currently documents official TypeScript support as `>=4.8.4 <6.1.0`, while TypeScript 7.0.2 is already published as stable. Because M0 is establishing a supported baseline rather than testing unsupported tool combinations, ADR-RI-009 changes the M0 compiler pin to TypeScript 5.9.3. This does not change Node.js 24.19.0 or npm 11.17.0 and is not an architecture failure.

Official compatibility reference:
https://typescript-eslint.io/users/dependency-versions/
