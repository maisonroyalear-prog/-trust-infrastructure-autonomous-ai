import { readFile, access } from 'node:fs/promises';

const workspaces = [
  'apps/trust-api',
  'apps/trust-worker',
  'apps/mock-erp',
  'packages/domain',
  'packages/application',
  'packages/persistence',
  'packages/api-contracts',
  'packages/event-contracts',
  'packages/gateway',
  'packages/evidence',
  'packages/receipt',
  'packages/security',
  'packages/config',
  'packages/testing',
];

const required = [
  'package.json',
  '.nvmrc',
  '.node-version',
  'tsconfig.base.json',
  'tsconfig.json',
  'eslint.config.mjs',
  '.prettierrc.json',
  '.env.example',
  '.npmrc',
  'scripts/toolchain-check.mjs',
  'scripts/secret-scan.mjs',
  '.github/workflows/ci.yml',
  'docs/implementation/M0-STEP-01-decisions.md',
  ...workspaces.flatMap((workspace) => [
    `${workspace}/package.json`,
    `${workspace}/tsconfig.json`,
    `${workspace}/src/index.ts`,
  ]),
];

for (const path of required) await access(path);

const pkg = JSON.parse(await readFile('package.json', 'utf8'));
if (pkg.engines.node !== '24.19.0') throw new Error('Node version is not locked to 24.19.0');
if (pkg.engines.npm !== '11.17.0') throw new Error('npm engine is not locked to 11.17.0');
if (pkg.packageManager !== 'npm@11.17.0') throw new Error('npm packageManager is not locked to 11.17.0');
if (pkg.workspaces.join(',') !== 'apps/*,packages/*') throw new Error('Unexpected workspace layout');
if (pkg.dependencies.fastify !== '5.12.1') throw new Error('Fastify not locked');
if (pkg.dependencies.kysely !== '0.29.5') throw new Error('Kysely not locked');
if (pkg.dependencies.zod !== '4.4.3') throw new Error('Zod not locked');
if (pkg.devDependencies['@eslint/js'] !== '10.0.1') throw new Error('@eslint/js not explicitly locked');
if (pkg.devDependencies.typescript !== '5.9.3') throw new Error('TypeScript M0 compatibility baseline not locked to 5.9.3');
if (pkg.devDependencies['typescript-eslint'] !== '8.67.0') throw new Error('typescript-eslint not locked');
if (pkg.scripts.test !== 'vitest run --passWithNoTests') throw new Error('M0 test runner must allow an empty bootstrap suite');
if (pkg.scripts['toolchain:check'] !== 'node scripts/toolchain-check.mjs') throw new Error('Exact toolchain check missing');
if (pkg.scripts['scan:secrets'] !== 'node scripts/secret-scan.mjs') throw new Error('Secret scan missing');
if (pkg.scripts['scan:dependencies'] !== 'npm audit --audit-level=high') throw new Error('Dependency audit missing');

const ciWorkflow = await readFile('.github/workflows/ci.yml', 'utf8');
if (!ciWorkflow.includes('workflow_dispatch:')) throw new Error('Normal CI must support explicit workflow_dispatch after bootstrap');
if (!ciWorkflow.includes('contents: read')) throw new Error('Normal CI must remain read-only');

const rootTsconfig = JSON.parse(await readFile('tsconfig.json', 'utf8'));
const referenced = new Set(rootTsconfig.references.map(({ path }) => path.replace(/^\.\//, '')));
for (const workspace of workspaces) {
  if (!referenced.has(workspace)) throw new Error(`Root tsconfig missing reference: ${workspace}`);
  const source = await readFile(`${workspace}/src/index.ts`, 'utf8');
  if (source.trim() !== 'export {};') throw new Error(`Non-empty implementation detected in ${workspace}/src/index.ts`);
}

console.log('M0-STEP-01 repository bootstrap static checks: PASS');
